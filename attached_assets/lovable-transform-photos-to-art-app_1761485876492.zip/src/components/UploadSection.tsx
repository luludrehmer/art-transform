import { useState } from "react";
import { Upload, Image as ImageIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

interface UploadSectionProps {
  onImageSelect: (file: File) => void;
  selectedImage: string | null;
}

const UploadSection = ({ onImageSelect, selectedImage }: UploadSectionProps) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith("image/")) {
      onImageSelect(file);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onImageSelect(file);
    }
  };

  return (
    <Card
      className={`border-2 border-dashed transition-all ${
        isDragging ? "border-accent bg-accent/5" : "border-border"
      }`}
      onDragOver={(e) => {
        e.preventDefault();
        setIsDragging(true);
      }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={handleDrop}
    >
      <div className="p-10">
        {selectedImage ? (
          <div className="space-y-4">
            <img
              src={selectedImage}
              alt="Preview"
              className="mx-auto max-h-64 rounded-lg shadow-[var(--shadow-medium)]"
            />
            <div className="text-center">
              <label htmlFor="file-upload">
                <Button variant="outline" asChild>
                  <span>Change Photo</span>
                </Button>
              </label>
            </div>
          </div>
        ) : (
          <div className="text-center space-y-4">
            <div className="mx-auto w-14 h-14 rounded-xl bg-accent/10 flex items-center justify-center">
              <Upload className="h-7 w-7 text-accent" />
            </div>
            <div>
              <p className="text-base font-medium mb-1">Drop your photo here</p>
              <p className="text-sm text-muted-foreground mb-4">
                or click to browse from your device
              </p>
            </div>
            <label htmlFor="file-upload">
              <Button variant="hero" size="lg" asChild>
                <span>
                  <ImageIcon className="mr-2 h-5 w-5" />
                  Select Photo
                </span>
              </Button>
            </label>
          </div>
        )}
        <input
          id="file-upload"
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleFileInput}
        />
      </div>
    </Card>
  );
};

export default UploadSection;
