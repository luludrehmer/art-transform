import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, Shield, Users, Palette, ExternalLink } from "lucide-react";

const UpsellSection = () => {
  return (
    <section className="py-12 px-4">
      <div className="container mx-auto max-w-6xl">
        <Card className="overflow-hidden border-2 shadow-[var(--shadow-large)]">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Video Section */}
            <div className="relative bg-muted/30 p-6 flex items-center justify-center">
              <div className="relative w-full aspect-video rounded-lg overflow-hidden shadow-[var(--shadow-medium)]">
                <iframe
                  className="w-full h-full"
                  src="https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1&mute=1&controls=1&rel=0"
                  title="Real Artists Creating Your Portrait"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>
            </div>

            {/* Content Section */}
            <div className="p-6 md:p-8">
              <Badge className="mb-3 bg-accent text-accent-foreground">
                Premium Service
              </Badge>
              
              <h2 className="font-display text-2xl md:text-3xl font-bold mb-3 text-gradient">
                Transform Your Digital Art Into a Real Masterpiece
              </h2>
              
              <p className="text-sm text-muted-foreground mb-4">
                Love your digital transformation? Our team of professional artists can create a 
                hand-painted <strong>oil painting</strong> from your AI-generated portrait.
              </p>

              {/* Trust Indicators */}
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="flex items-start space-x-2">
                  <Users className="h-4 w-4 text-accent mt-0.5" />
                  <div>
                    <p className="font-semibold text-xs">2,300+</p>
                    <p className="text-xs text-muted-foreground">Happy Customers</p>
                  </div>
                </div>
                <div className="flex items-start space-x-2">
                  <Star className="h-4 w-4 text-accent mt-0.5" />
                  <div>
                    <p className="font-semibold text-xs">4.9/5 Rating</p>
                    <p className="text-xs text-muted-foreground">Verified Reviews</p>
                  </div>
                </div>
                <div className="flex items-start space-x-2">
                  <Palette className="h-4 w-4 text-accent mt-0.5" />
                  <div>
                    <p className="font-semibold text-xs">Real Artists</p>
                    <p className="text-xs text-muted-foreground">Hand-Painted</p>
                  </div>
                </div>
                <div className="flex items-start space-x-2">
                  <Shield className="h-4 w-4 text-accent mt-0.5" />
                  <div>
                    <p className="font-semibold text-xs">100% Guarantee</p>
                    <p className="text-xs text-muted-foreground">Quality Assured</p>
                  </div>
                </div>
              </div>

              {/* Trust Badges */}
              <div className="flex flex-wrap gap-1.5 mb-6">
                <Badge variant="outline" className="text-xs">✓ Museum Quality</Badge>
                <Badge variant="outline" className="text-xs">✓ Free Shipping</Badge>
                <Badge variant="outline" className="text-xs">✓ Money-Back Guarantee</Badge>
              </div>

              <Button
                variant="premium"
                size="lg"
                className="w-full group"
                asChild
              >
                <a 
                  href="https://portraits.art-and-see.com" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center justify-center"
                >
                  Create My Real Portrait
                  <ExternalLink className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </a>
              </Button>

              <p className="text-xs text-center text-muted-foreground mt-3">
                The perfect gift for yourself or loved ones
              </p>
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
};

export default UpsellSection;
